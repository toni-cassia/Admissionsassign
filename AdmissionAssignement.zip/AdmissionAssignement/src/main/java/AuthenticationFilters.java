import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/admission")
public class AuthenticationFilters implements Filter {
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) resp;

        HttpSession session = request.getSession(false); // Do not create a new session if one does not exist

        boolean loggedIn = session != null && session.getAttribute("email") != null;

        if (loggedIn || request.getRequestURI().endsWith("signin.jsp") || request.getRequestURI().endsWith("signin")) {
            // User is logged in or accessing the login page or attempting to sign in, proceed
            chain.doFilter(req, resp);
        } else {
            // User is not logged in, redirect to login page
            response.sendRedirect(request.getContextPath() + "/signin.jsp");
        }
    }
}
