package com.keziah.admissionassignement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

@WebServlet("/admission")
@MultipartConfig
public class AdmissionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String firstName = request.getParameter("first-name");
        String lastName = request.getParameter("last-name");
        String email = request.getParameter("email");
        String department = request.getParameter("department");
        String messageContent = request.getParameter("message");

        // Process uploaded files (if any)
        // (You may need to adjust this based on your form and requirements)
        Part passportPart = request.getPart("passport");
        Part diplomaPart = request.getPart("diploma");

        // Construct the email content
        String emailSubject = "Admission Form Submission";
        String emailBody = "First Name: " + firstName + "\n" +
                "Last Name: " + lastName + "\n" +
                "Email: " + email + "\n" +
                "Department: " + department + "\n" +
                "Additional Message: " + messageContent;

        // Send the email
        sendEmail(email, emailSubject, emailBody);

        // Send confirmation response to the user
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body><h1>Admission Submitted Successfully</h1></body></html>");
    }

    // Method to send email
    private void sendEmail(String recipientEmail, String subject, String body) {
        // Configure email sender and properties
        final String senderEmail = "kemutoni12@gmail.com";
        final String senderPassword = "Psalms91:7";
        Properties props = new Properties();
        props.put("mail.smtp.auth", true);
        props.put("mail.smtp.starttls.enable", true);
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        // Create email session
        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
                return new javax.mail.PasswordAuthentication(senderEmail, senderPassword);
            }
        });

        try {
            // Create email message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(senderEmail));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject(subject);
            message.setText(body);

            // Send the email message
            Transport.send(message);

            System.out.println("Email sent successfully to: " + recipientEmail);
        } catch (Exception e) {

            System.err.println("Error sending email: " + e.getMessage());
        }
    }
}
