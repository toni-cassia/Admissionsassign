package com.keziah.admissionassignement;


import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/signup")
public class SignUpServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private Map<String, String> userCredentials = new HashMap<>();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        if (email != null && password != null && !email.isEmpty() && !password.isEmpty()) {
            if (!userCredentials.containsKey(email)) {
                // Store user credentials in memory
                userCredentials.put(email, password);
                response.sendRedirect("signin.jsp"); // Redirect to login page after successful signup
            } else {
                // User already exists
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.println("<html><body><h1>User already exists</h1></body></html>");
            }
        } else {
            // Invalid form submission
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><body><h1>Invalid email or password</h1></body></html>");
        }
    }
}
