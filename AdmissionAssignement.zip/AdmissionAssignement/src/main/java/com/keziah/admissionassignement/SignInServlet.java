package com.keziah.admissionassignement;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

@WebServlet(name = "signin", urlPatterns = {"/signin"})
public class SignInServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final Map<String, String> userCredentials = new HashMap<>();

    // Pre-populate some user credentials for demonstration purposes
    public void init() {
        userCredentials.put("user1@example.com", "password1");
        userCredentials.put("user2@example.com", "password2");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        if (email != null && password != null && !email.isEmpty() && !password.isEmpty()) {
            if (userCredentials.containsKey(email) && userCredentials.get(email).equals(password)) {
                // Successful login, store user details in session
                HttpSession session = request.getSession();
                session.setAttribute("email", email);
                sendEmailConfirmation(email);
                response.sendRedirect("admission.jsp"); // Redirect to admission page after successful login
            } else {
                // Invalid credentials
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.println("<html><body><h1>Invalid email or password</h1></body></html>");
            }
        } else {
            // Invalid form submission
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><body><h1>Invalid email or password</h1></body></html>");
        }
    }

    private void sendEmailConfirmation(String recipientEmail) {
        // Email sending logic
        final String username = "kemutoni12@gmail.com";
        final String password = "Psalms91:7";

        Properties props = new Properties();
        props.put("mail.smtp.auth", true);
        props.put("mail.smtp.starttls.enable", true);
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
                new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject("Sign-in Confirmation");
            message.setText("You have successfully signed in.");

            Transport.send(message);
        } catch (Exception e) {
            e.printStackTrace();
            
        }
    }
}
